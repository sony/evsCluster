#!/usr/bin/env python
# coding: utf-8

# In[1]:


import numpy as np
from config import config_by_gui
from config import config
from config import common



kernel_size_half = config.KERNEL_SIZE//2 # default: 2, since the default value of "KERNEL_SIZE" is 5
border_left = kernel_size_half+1
border_right = config.WIDTH-(kernel_size_half+2)
border_up = kernel_size_half+1
border_down = config.HEIGHT-(kernel_size_half+2)

def noise_filter():
    for new_pxl in common.list_new_pxls:
        new_x, new_y = new_pxl[0], new_pxl[1]

        if (new_x < border_left) or (border_right < new_x) or (new_y < border_up) or (border_down < new_y): # this should be faster than "and"
            continue

        new_y_up = new_y-kernel_size_half
        new_y_down = new_y+(kernel_size_half+1)
        new_x_left = new_x-kernel_size_half
        new_x_right = new_x+(kernel_size_half+1)

        # check if neighbouring pixels have had a descent amount of events recently
        binary_img_buf_neighbour_sum = common.binary_img_buf[ : , new_y_up : new_y_down , new_x_left : new_x_right ].sum() - common.binary_img_buf[ : , new_y , new_x ].sum() # subtract the center
        if binary_img_buf_neighbour_sum >= config_by_gui.NEIGHBOUR_TH:
            common.list_filtered_pxls.append(new_pxl)

    common.list_new_pxls.clear()
    common.binary_img_idx += 1 # rotate
    common.binary_img_idx %= config.NUM_BINARY_IMG_BUF # initialize if necessary
    common.binary_img_buf[common.binary_img_idx] = np.copy(common.blank_binary_img) # initialize with 0s



def save_filtered_pxls():
    common.f_filtered.write( ( common.timestamp_ms ).to_bytes(4, byteorder='little') ) # timestamp. 4 bytes

    for new_pxl in common.list_filtered_pxls:
        common.f_filtered.write( ( new_pxl[2] ).to_bytes(1, byteorder='little') ) # polarity. 1 byte
        common.f_filtered.write( ( new_pxl[0] ).to_bytes(2, byteorder='little') ) # x. 2 bytes
        common.f_filtered.write( ( new_pxl[1] ).to_bytes(2, byteorder='little') ) # y. 2 bytes

    common.f_filtered.write( b'\xFF' ).to_bytes(2, byteorder='little') # separator 1 byte

    common.list_filtered_pxls.clear()



def add_new_pxl(x, y, polarity):
    common.list_new_pxls.append( [x, y, polarity] )
    common.binary_img_buf[common.binary_img_idx][ y, x ] += 1



def close_files():
    if not common.f_input.closed:
        common.f_input.close()

    if not common.f_filtered.closed:
        common.f_filtered.close()

    if not common.f_sub.closed:
        for subcluster in common.subclusters[:]:
            save_subcluster(subcluster)

        common.f_sub.write( b'\x00\x00\x00\x00' ).to_bytes(4, byteorder='little') # marker of EOF
        common.f_sub.close()



x_base_shift = 1

def process_data(input_f_path, filtered_f_path, output_f_path):
    common.timestamp_ms = 0

    common.blank_binary_img = np.zeros((config.HEIGHT, config.WIDTH), dtype=np.int8)
    common.binary_img_buf = np.zeros((config.NUM_BINARY_IMG_BUF, config.HEIGHT, config.WIDTH), dtype=np.int8)
    common.binary_img_idx = 0

    common.img_subcluster_idxes = np.zeros((config.HEIGHT, config.WIDTH), dtype=np.int32)
    common.blank_img_idx = np.zeros((config.HEIGHT, config.WIDTH), dtype=np.int32)

    common.list_new_pxls = [] # [ [x, y, polarity] , [] ,,, [] ]
    common.list_filtered_pxls = []

    common.subclusters = []
    common.subcluster_cnter = 0 # for indexing of the "clusters" list
    common.subcluster_id = 0

    # open a file to store subclusters in binary compressed form: .sub
    common.f_sub_path = output_f_path
    common.f_sub = open(common.f_sub_path, "wb")

    # local variables
    tmp_y = 0
    time_high = 4097 # values over 4096 are invalid
    polarity = True
    x_base = 0

    last_time_high = 0 # [us]
    time_high_1st = 0 # [us]
    timestamp_offset = 0 # [us]
    last_time_clustering_new_pxls = 0 # [us]
    common.last_time_updating_subclusters = 0 # [us]

    common.f_input = open(input_f_path, "rb")
    common.f_filtered = open(filtered_f_path, "wb")

    byte_1st = common.f_input.read(1)
    byte_2nd = common.f_input.read(1)

    # check if timestamp has been updated to valid range
    while byte_1st: # while byte_1st != b'':
        #if ( int.from_bytes(byte_2nd, byteorder="big") & int.from_bytes(tmp_byte, byteorder="big") ) == int.from_bytes(tmp_byte, byteorder="big"):
        cur_event_type = byte_2nd[0] & config.MASK_EVENT_TYPE[0]

        if cur_event_type == config.EVENT_TYPE_TIME_LOW[0]:
            # concatenate 4 + 8 bits
            timestamp = time_high + ( byte_2nd[0] & config.MASK_VALUE_0F[0] )*256 + byte_1st[0]

            # if timestamp has been updated to valid range, break
            if time_high != 4097:
                break

        elif cur_event_type == config.EVENT_TYPE_TIME_HIGH[0]:
            # concatenate 4 + 8 bits
            if time_high == 4097:
                time_high_1st = ( byte_2nd[0] & config.MASK_VALUE_0F[0] )*256 + byte_1st[0]
                time_high = 0
                last_time_high = time_high
                last_time_high_byte_1st = byte_1st[0]

            elif byte_1st[0] != last_time_high_byte_1st:
                # when "byte_1st[0]" for "time_high" changed from the last time
                time_high = ( ( byte_2nd[0] & config.MASK_VALUE_0F[0] )*256 + byte_1st[0] - time_high_1st + timestamp_offset ) * 4096

                if time_high < last_time_high:
                    timestamp_offset += 4096
                    time_high = ( ( byte_2nd[0] & config.MASK_VALUE_0F[0] )*256 + byte_1st[0] - time_high_1st + timestamp_offset ) * 4096

                last_time_high = time_high
                last_time_high_byte_1st = byte_1st[0]

        # read the next 2 bytes
        byte_1st = common.f_input.read(1)
        byte_2nd = common.f_input.read(1)

    # "while loop" which lasts until the EOF
    while byte_1st:
        cur_event_type = byte_2nd[0] & config.MASK_EVENT_TYPE[0]

        if cur_event_type == config.EVENT_TYPE_X_POS[0]:
            # check Contrast Detection polarity
            polarity = bool(byte_2nd[0] & config.MASK_VALUE_08[0]) # bool(0x0800 or 0x0000)

            # concatenate 3 + 8 bits
            tmp_x = ( byte_2nd[0] & config.MASK_VALUE_07[0] )*256 + byte_1st[0]

            add_new_pxl( tmp_x, tmp_y, polarity )

        elif cur_event_type == config.EVENT_TYPE_CD_Y[0]:
            # concatenate 3 + 8 bits
            tmp_y = ( byte_2nd[0] & config.MASK_VALUE_07[0] )*256 + byte_1st[0]

        elif cur_event_type == config.EVENT_TYPE_TIME_LOW[0]:
            # concatenate 4 + 8 bits
            timestamp = time_high + ( byte_2nd[0] & config.MASK_VALUE_0F[0] )*256 + byte_1st[0]
            common.timestamp_ms = timestamp//1000

            if ( timestamp - last_time_clustering_new_pxls ) >= config.CLUSTERING_NEW_PXLS_DUR:
                noise_filter()
                save_filtered_pxls()

                last_time_clustering_new_pxls = timestamp - (timestamp % config.CLUSTERING_NEW_PXLS_DUR) # update with truncation

        elif cur_event_type == config.EVENT_TYPE_TIME_HIGH[0]:
            # concatenate 4 + 8 bits
            if byte_1st[0] != last_time_high_byte_1st:
                # when "byte_1st[0]" for "time_high" changed from the last time
                time_high = ( ( byte_2nd[0] & config.MASK_VALUE_0F[0] )*256 + byte_1st[0] - time_high_1st + timestamp_offset ) * 4096

                if time_high < last_time_high:
                    timestamp_offset += 4096
                    time_high = ( ( byte_2nd[0] & config.MASK_VALUE_0F[0] )*256 + byte_1st[0] - time_high_1st + timestamp_offset ) * 4096

                last_time_high = time_high
                last_time_high_byte_1st = byte_1st[0]

        elif cur_event_type == config.EVENT_TYPE_X_BASE[0]:
            # check Contrast Detection Polarity
            polarity =  bool(byte_2nd[0] & config.MASK_VALUE_08[0]) # bool(0x0800 or 0x0000)

            # concatenate 3 + 8 bits
            x_base = ( byte_2nd[0] & config.MASK_VALUE_07[0] )*256 + byte_1st[0]

        elif cur_event_type == config.EVENT_TYPE_VECT_12[0]:
            bit_mask = 1
            for j in range(8):
                if byte_1st[0] & bit_mask:
                    add_new_pxl( x_base, tmp_y, polarity )
                bit_mask = bit_mask << 1
                x_base = x_base + x_base_shift

            bit_mask = 1
            for j in range(4):
                if byte_2nd[0] & bit_mask:
                    add_new_pxl( x_base, tmp_y, polarity )
                bit_mask = bit_mask << 1
                x_base = x_base + x_base_shift

        elif cur_event_type == config.EVENT_TYPE_VECT_8[0]:
            bit_mask = 1
            for j in range(8):
                if byte_1st[0] & bit_mask:
                    add_new_pxl( x_base, tmp_y, polarity )
                bit_mask = bit_mask << 1
                x_base = x_base + x_base_shift

        elif cur_event_type == config.EVENT_TYPE_CONTINUED_4[0]:
            pass

        elif cur_event_type == config.EVENT_TYPE_EXT_TRIGGER[0]:
            pass

        elif cur_event_type == config.EVENT_TYPE_OTHERS[0]:
            pass

        elif cur_event_type == config.EVENT_TYPE_CONTINUED_12[0]:
            pass

        else :
            pass

        # read the next 2 bytes
        byte_1st = common.f_input.read(1)
        byte_2nd = common.f_input.read(1)

    # close_files()


# In[2]:


if __name__ == "__main__":
    process_data("plankton_sample.raw", "plankton_sample.flt", "plankton_sample.sub")
    close_files()


# In[10]:





# In[ ]:




